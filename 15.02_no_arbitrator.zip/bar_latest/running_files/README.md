# pc_architecture_proj
multi core pipelined cpu
